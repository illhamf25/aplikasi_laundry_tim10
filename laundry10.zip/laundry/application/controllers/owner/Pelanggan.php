<?php


defined('BASEPATH') OR exit('No direct script access allowed');

class Pelanggan extends CI_Controller {
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Admin/Pelanggan_model', 'PelangganModel');
    }

    public function index()
    {
        $title['title'] = ['header'=>'Member', 'dash'=>'Member'];
        $data['data'] = $this->PelangganModel->select();
        $this->load->view('Owner/template/header', $title);
        $this->load->view('Owner/pelanggan', $data);
        $this->load->view('Owner/template/footer');
    }

    function simpan()
    {
        $data = $this->input->post();
        if($data['kd_pelanggan']==""){
            $result = $this->PelangganModel->insert($data);
            if($result)
                $this->session->set_flashdata('pesan', 'Data berhasil disimpan, success');
            else
                $this->session->set_flashdata('pesan', 'Data gagal disimpan, error');
            redirect('Owner/pelanggan');
        }else{
            $data = $this->input->post();
            $result = $this->PelangganModel->update($data);
            if($result)
                $this->session->set_flashdata('pesan', 'Data berhasil diubah, success');
            else
                $this->session->set_flashdata('pesan', 'Data gagal diubah, error');
            redirect('Owner/pelanggan');
        }
    }
    
    function hapus($kd_pelanggan)
    {
        if($this->PelangganModel->delete($kd_pelanggan))
            $this->session->set_flashdata('pesan', 'Data berhasil dihapus, success');
        else
            $this->session->set_flashdata('pesan', 'Data gagal dihapus, error');
        redirect('Owner/pelanggan');
    }
}

/* End of file Controllername.php */
