<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Profile extends CI_Controller {
    
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Admin/Profile_model', 'ProfileModel');        
    }
    

    public function index()
    {
        $title['title'] = ['header'=>'Profile Outlet', 'dash'=>'Profile'];
        $data['data'] = $this->ProfileModel->select();
        $this->load->view('Owner/template/header', $title);
        $this->load->view('Owner/profile', $data);
        $this->load->view('Owner/template/footer', $title);
    }
    function simpan()
    {
        $data = $this->input->post();
        $result =  $this->ProfileModel->insert($data);
        if($result['status']){
            $this->session->set_flashdata('pesan', $result['message']);
			redirect('Owner/profile');
        }else{
            $this->session->set_flashdata('pesan', $result['message']);
			redirect('profile');
        }
    }
    public function getprofile()
    {
        $data = $this->ProfileModel->select();
        echo json_encode($data);
    }

}

/* End of file Profile.php */

