<div class="d-flex flex-column" id="content-wrapper" style="color: var(--bs-indigo);">
            <div class="cont_principal" style="margin-top: -76px;background: var(--bs-blue);color: var(--bs-blue);border-bottom-color: var(--bs-purple);">
                <div class="cont_central" style="padding-left: 0px;width: 1025px;">
                    <div class="cont_modal cont_modal_active">
                        <div class="cont_photo">
                            <div class="cont_img_back" style="background: linear-gradient(var(--bs-blue) 84%, white);border-radius: 10px;"><img src="<?= base_url('assets/'); ?>/img/logo.png" style="width: 117px;margin: 90px;margin-bottom: 90px;margin-top: 170px;"></div>
                            <div class="cont_mins" style="border-radius: 63px;">
                                <div class="cont_icon_right"><a href="#"></a></div>
                            </div>
                            <div class="cont_detalles"></div>
                        </div>
                        <div class="cont_text_ingredients">
                            <div class="cont_over_hidden" style="color: var(--bs-blue);background: linear-gradient(var(--bs-blue), var(--bs-gray-dark)), var(--bs-blue);">
                                <div class="cont_text_det_preparation">
                                    <div class="cont_title_preparation">
                                        <p style="color: var(--bs-gray-100);font-size: 21px;">Jumlah Member</p>
                                    </div>
                                    <div class="cont_info_preparation" style="color: var(--bs-gray-900);">
                                        <p style="font-size: 29px;color: var(--bs-gray-100);">1</p>
                                    </div>
                                    <div class="cont_text_det_preparation">
                                        <div class="cont_title_preparation">
                                            <p style="color: var(--bs-light);font-size: 21px;">Pemasukan</p>
                                        </div>
                                        <div class="cont_info_preparation">
                                            <p style="font-size: 21px;color: var(--bs-gray-100);">RP.315.000</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="cont_btn_mas_dets"><a href="#"></a></div>
                            </div>
                            <div class="cont_btn_open_dets"><a href="#e" onclick="open_close()"><i class="material-icons">keyboard_arrow_right</i></a></div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="content">
                <div class="container-fluid">
                    <div class="d-sm-flex justify-content-between align-items-center mb-4"></div>
                </div>
            </div>
        </div><a class="border rounded d-inline scroll-to-top" href="#page-top"><i class="fas fa-angle-up"></i></a>
    </div>
    