<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?= $title['header']?></title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?= base_url();?>assets/plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- icheck bootstrap -->
  <link rel="stylesheet" href="<?= base_url();?>assets/plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?= base_url();?>assets/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <link rel="stylesheet" href="<?= base_url('assets/bootstrap/css/bootstrap.min.css');?>">
    <link rel="stylesheet" href="<?= base_url('https://fonts.googleapis.com/css?family=Aclonica&amp;display=swap');?>">
    <link rel="stylesheet" href="<?= base_url('https://fonts.googleapis.com/css?family=Alatsi&amp;display=swap');?>">
    <link rel="stylesheet" href="<?= base_url('assets/fonts/material-icons.min.css');?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/Login-Form-Dark.css');?>">
    <link rel="stylesheet" href="<?= base_url('assets/css/styles.css');?>">
</head>
<body>
  <section class="login-dark" style="color: var(--bs-blue);filter: blur(0px) grayscale(0%);background: url(&quot;assets/img/laundryroom1.png&quot;) bottom / cover;border-style: solid;">
        <form action="<?= base_url();?>authorization/login" method="post" style="width: 320px;height: 377px;margin: 0px;padding: 52px;color: var(--bs-gray-dark);background: linear-gradient(var(--bs-blue), #55a6ff), #55a6ff;margin-top: -76px;margin-left: 5px;">
        <h2 class="visually-hidden">Login Form</h2><img src="assets/img/logo.png" style="width: 262px;padding: -35px;padding-right: 73px;padding-top: 0px;padding-left: 91px;margin-right: -44px;min-height: 0px;height: 86.9px;margin-top: -7px;margin-left: -35px;">
        <div class="illustration"></div>
            <div class="mb-3"><input type="text" class="form-control" type="email" name="username" placeholder="Username" style="color: var(--bs-body-color);background: var(--bs-gray-100);"></div>
            <div class="mb-3"><input type="password" class="form-control" name="password" placeholder="Password" style="background: var(--bs-gray-100);"></div>
            <div class="mb-3"><button class="btn btn-primary d-block w-100" type="submit">Log In</button></div>
          
        </form>
    </section>

  <!-- /.login-box -->

  <!-- jQuery -->
  <script src="<?= base_url();?>assets/plugins/jquery/jquery.min.js"></script>
  <!-- Bootstrap 4 -->
  <script src="<?= base_url();?>assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- AdminLTE App -->
  <script src="<?= base_url();?>assets/dist/js/adminlte.min.js"></script>
  <script src="<?= base_url();?>assets/node_modules/sweetalert/dist/sweetalert.min.js"></script>
  <script type="text/javascript">
    $(function () {
      $(document).ready(function () {
          var data = $('.data-flush').data('flash');
          console.log(data);
          if (data) {
              var a = data.split(',');
              if (a[1].replace(/\s/g, '') == 'success') {
                  swal("Information!", a[0], "success");
              } else {
                  swal("Information!", a[0], "error");
              }
          }
      })
    })
  </script>

</body>

</html>