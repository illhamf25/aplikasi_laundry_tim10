<div class="row">
  <div class="col-md-8">
    <div class="card card-warning">
      <div class="card-header" style="background: rgb(7,41,92);">
        <h3 class="card-title text-white">Data Member</h3>
      </div>
      <div class="card-body">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th style="width: 10px">No</th>
              <th>Nama</th>
              <th>Kontak</th>
              <th>Jenis Kelamin</th>
              <th>Alamat</th>
              <th style="width: 15%">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php
              $no =1;
              foreach($data as $item):?>
            <tr>
              <td><?= $no?></td>
              <td><?= $item->nama?></td>
              <td><?= $item->no_hp?></td>
              <td><?= $item->jk?></td>
              <td><?= $item->alamat?></td>
              <td>
            
                <div class="tombol">
                  <bottom class="btn btn-danger hapuspelanggan"
                    data-url="<?= base_url().'Owner/pelanggan/hapus/'.$item->kd_pelanggan?>">
                    <ion-icon name="trash-outline"></ion-icon>
                  </bottom>
                </div>
              </td>
            </tr>
            <?php 
              $no ++;
            endforeach;
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<script>
  $(function () {
    $(document).ready(function () {
      var tombol;
      var kd_pelanggan;
      var nama;
      var no_hp;
      var jk;
      var alamat;
      if (document.getElementById("kd_pelanggan").value == "") {
        $('.prosess').val('Simpan');
      } else {
        $('.prosess').val('Ubah');
      }
      // get Edit Product
      $('.btn-default').on('click', function () {
        $(".username").hide();
        // get data from button edit
        kd_pelanggan = $(this).data('kd_pelanggan');
        nama = $(this).data('nama');
        no_hp = $(this).data('no_hp');
        jk = $(this).data('jk');
        alamat = $(this).data('alamat');
        // Set data to Form Edit
        $('#kd_pelanggan').val(kd_pelanggan);
        $('#nama').val(nama);
        $('#no_hp').val(no_hp);

        $('#alamat').val(alamat);
        if (jk == 'Wanita')
          $('#jk2').prop('checked', true);
        else
          $('#jk1').prop('checked', true);
        $('.prosess').val('Ubah');
      });

      $('.clear').on('click', function () {
        $('#kd_pelanggan').empty();
        $('#nama').empty();
        $('#no_hp').empty();

        $('#alamat').empty();
        $('#jk1').prop('checked', true);
        $('.prosess').val('Simpan');
        $(".username").show();
      });

      // get Delete Product
      $('.hapuspelanggan').on('click', function () {
        // get data from button edit
        const Url = $(this).data('url');
        // Set data to Form Edit
        // $('.edit-kategori').val(idkategori);
        swal({
          title: "Anda Yakin?",
          text: "Akan Melakukan Penghapusan data?",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
          .then((willDelete) => {
            if (willDelete) {
              $.ajax({
                type: 'DELETE',
                url: Url,
                success: function (data) {
                  swal("Information!", "Berhasil di Hapus", "success")
                    .then((value) => {
                      location.reload();
                    });
                }
              });
            }
          });
      });
    });
  })
</script>